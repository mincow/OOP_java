/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Bai_4 {
    public static void main (String[] args) {
        int a[][];
        Scanner x = new Scanner(System.in);
        System.out.print("Nhap so dong: ");
        int d  = x.nextInt();
        System.out.print("Nhap so cot: ");
        int c  =  x.nextInt();
        a = new int[c][d];
        for (int i = 0; i < c; i++) {
            for (int j = 0; j < d; j++) {
                System.out.print("A[" + i + "][" + j + "] = ");
                a[i][j] = x.nextInt();
            }
        }
        /*for (int i = 0; i < c; i++) {
            for (int j = 0; j < d; j++) {
                a[i][j] = (int) (Math.random()*100);
            }
        }*/
            
            
        System.out.println("Mang vua nhap la: ");
        for (int i = 0; i < c; i++) {
            for (int j = 0; j < d; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }
}
