/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Bai_5 {
   
            
    public static void main (String[] args) {
        HocSinh hs = new HocSinh();
        hs.input();
        hs.output();
        hs.rank();
        System.out.println("Ho ten vua nhap: " + hs.getHoTen());
        String name = "NewName";
        hs.setHoTen(name);
        System.out.println("Ten mới: " + hs.getHoTen());
        
        
        
         
    }
}
