/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class phanSo {

    /**
     * @return the tuSo
     */
    public int getTuSo() {
        return tuSo;
    }

    /**
     * @param tuSo the tuSo to set
     */
    public void setTuSo(int tuSo) {
        this.tuSo = tuSo;
    }

    /**
     * @return the mauSo
     */
    public int getMauSo() {
        return mauSo;
    }

    /**
     * @param mauSo the mauSo to set
     */
    public void setMauSo(int mauSo) {
        this.mauSo = mauSo;
    }
    private int tuSo;
    private int mauSo;
    
    public void input() {
        Scanner x = new Scanner(System.in);
        System.out.print("Nhập tử số: ");
        tuSo = x.nextInt();
        do {
            System.out.print("Nhập mẫu số: ");
            mauSo = x.nextInt();
            if (mauSo == 0) {
                System.out.println("Mẫu phải khác 0 !! Nhập lại !!!");
            }
        } while (mauSo ==0 );
        
        
    }
    public void output() {
        if (tuSo >= mauSo && tuSo%mauSo == 0) {
            System.out.println(tuSo/mauSo);
        }
        else {
            System.out.println(this.tuSo + "/" + this.mauSo); 
        }
    }
    
    public phanSo rutGonPhanSo() {
        int ucln = 1;
        phanSo kq = new phanSo();
        /*for (int i = tuSo; i >= 1; i--) {
            if (i % tuSo == 0 && i%mauSo == 0) {
                ucln = i;
            }
        }*/
        for(int i = 1; i <= tuSo && i <= mauSo; i++)
        {
            if(tuSo%i==0 && mauSo%i==0)
                ucln = i;
        }
        kq.tuSo = this.tuSo/ucln;
        kq.mauSo = this.mauSo/ucln;
        return kq;  
    }
    public phanSo tongPhanSo(phanSo ps2) {
        phanSo sum = new phanSo();
        if (tuSo == mauSo) {
            sum.tuSo = this.tuSo + this.mauSo;
            sum.mauSo = this.mauSo;
        }
        else {
            sum.tuSo = this.tuSo*ps2.mauSo + this.mauSo*ps2.tuSo;
            sum.mauSo = this.mauSo*ps2.mauSo;
        }
        return sum.rutGonPhanSo();
    }
}

