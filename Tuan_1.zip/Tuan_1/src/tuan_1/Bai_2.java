/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Bai_2 {
    public static void main (String agrs[]) {
        Scanner x = new Scanner(System.in);
        System.out.println("Nhap ma sinh vien: ");
        String mssv = x.nextLine();
        System.out.println("Nhap Ho ten: ");
        String name = x.nextLine();
        System.out.println("Nhap tuoi: ");
        int age = x.nextInt();
        System.out.println("Nhap nam sinh: ");
        int year = x.nextInt();
        System.out.println("Nhap Diem trung binh: ");
        float dtb = x.nextFloat();
        System.out.print("Ho ten sinh vien: \n" + name + "\n" + "MSSV: " + mssv + "\nTuoi: " + age + "\nNam sinh: " + year + "\nDiem trung binh: " + dtb);
    }
}
