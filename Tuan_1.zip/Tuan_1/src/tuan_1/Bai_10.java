/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

/**
 *
 * @author Administrator
 */
public class Bai_10 {
    public static void main (String[] args) {
        phanSo ps1 = new phanSo();
        phanSo ps2 = new phanSo();
        System.out.println("Nhập phân số thứ nhất: ");
        ps1.input();
        System.out.println("\nNhập phân số thứ 2: ");
        ps2.input();
        /*ps1.rutGonPhanSo();
        System.out.println("Phan so sau khi rut gon: ");
        ps1.output();*/
        phanSo kq = new phanSo();
        kq = ps1.tongPhanSo(ps2);
        System.out.print("Tổng 2 phân số là: ");
        kq.output();
        
    }
}
