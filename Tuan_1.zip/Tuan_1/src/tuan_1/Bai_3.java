/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Bai_3 {
    public static void main (String[] args) {
        int a[];
        System.out.println("Nhap mang so nguyen: ");
        Scanner  x = new Scanner(System.in);
        System.out.print("Nhap so phan tu: ");
        int n = x.nextInt();
        a = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("A[" + i + "] = ");
            a[i] = x.nextInt();
        }
        int max = a[0];
        System.out.print("Mang so nguyen vua nhap la: ");
        for (int i = 0; i < n; i++) {
            if (a[i] > max)
                max = a[i];
            System.out.print(a[i] + " ");
        }
        System.out.println("\nPhan tu lon nhat la: " + max);
    }
}
