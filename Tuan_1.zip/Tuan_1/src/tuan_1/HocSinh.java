/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class HocSinh {

    /**
     * @return the maSo
     */
    public int getMaSo() {
        return maSo;
    }

    /**
     * @param maSo the maSo to set
     */
    public void setMaSo(int maSo) {
        this.maSo =  maSo;
    }

    /**
     * @return the hoTen
     */
    public String getHoTen() {
        return hoTen;
    }

    /**
     * @param hoTen the hoTen to set
     */
    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    /**
     * @return the dtb
     */
    public float getDtb() {
        return dtb;
    }

    /**
     * @param dtb the dtb to set
     */
    public void setDtb(float dtb) {
        this.dtb = dtb;
    }

  
    private int maSo;
    private String hoTen;
    private float dtb;
   
    
    
    
    public void input() {
        Scanner x = new Scanner(System.in);
        System.out.print("Nhap hoc ten hoc sinh: ");
        hoTen = x.nextLine();
        System.out.print("\nNhap ma so hoc sinh: ");
        maSo = x.nextInt();
        System.out.print("\nNhap Diem trung bình: ");
        dtb = x.nextFloat();
    }
    public void output() {
        System.out.println("Ho ten: " + getHoTen());
        System.out.println("Mshs: " + getMaSo());
        System.out.println("Diem trung binh: " + getDtb());
    }
    public void rank() {
        if (getDtb() > 5) {
            System.out.println("Xếp loại: Yếu");
        }
        else {
            if (getDtb() >= 5 && getDtb() < 7) {
                System.out.println("Xếp loại: Trung bình");
            }
            else {
                if (getDtb() >= 7 && getDtb() < 8) {
                    System.out.println("Xếp loại: Khá");
                }
                else
                    System.out.println("Xếp loại: Giỏi");
            }
        }
    }
            
}
