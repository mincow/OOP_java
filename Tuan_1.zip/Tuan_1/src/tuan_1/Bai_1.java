
import java.util.Scanner;


class Bai_1 {
    public static void main (String agrs[]) {
        Scanner x = new Scanner(System.in);
        System.out.print("Xin moi nhap ten: ");
        String name = x.nextLine();
        System.out.print("Nhap tuoi: ");
        int age = x.nextInt();
        System.out.println("Hello! I'm " + name);
        System.out.println("I'm " + age + " years old");
        System.out.println("This is my first java program.");
    }
}
