/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuan_1;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Bai_9 {
    public static void main (String[] args) {
        int a[][];
        Scanner x = new Scanner(System.in);
        System.out.print("Nhap so dong: ");
        int d  = x.nextInt();
        System.out.print("Nhap so cot: ");
        int c  =  x.nextInt();
        a = new int[d][c];
        for (int i = 0; i < d; i++) {
            for (int j = 0; j < c; j++) {
                System.out.print("A[" + i + "][" + j + "] = ");
                a[i][j] = x.nextInt();
            }
        }
        System.out.println("Mang vua nhap la: ");
        for (int i = 0; i < d; i++) {
            for (int j = 0; j < c; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Nhập hàng cần tính tổng: ");
        int k = x.nextInt();
        int sum = 0;
        for (int i = 0; i < c;i++) {
            sum += a[k-1][i];
        }
        System.out.println("Tổng các phần tử hàng " + k + " là: " + sum);
        
    }
}
